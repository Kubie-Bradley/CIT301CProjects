import { Component } from '@angular/core';

@Component({
  selector: 'cms-root',
  templateUrl: 'cms-app.component.html'
})
export class AppComponent {
  title = 'cms works!';
}
