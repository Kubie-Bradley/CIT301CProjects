export class Message {
  constructor(public id, public sender, public subject, public text) {

  }
}
