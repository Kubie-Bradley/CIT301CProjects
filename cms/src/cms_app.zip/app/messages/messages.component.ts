import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cms-messages',
  templateUrl: './messages.component.html'
})
export class MessagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
