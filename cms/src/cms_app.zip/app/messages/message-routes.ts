import {MessageNewComponent} from "./message-new/message-new.component";
import {Routes} from "@angular/router";
export const MESSAGE_ROUTES: Routes = [
  // { path: '', component: MessageNewComponent  },
  { path: 'new', component: MessageNewComponent }
  // { path: ':id', component:},
  // { path: ':id/edit', component: MessageNewComponent }
];
